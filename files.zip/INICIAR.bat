@echo off
title LuxTranslator
color 0A
echo.
echo  ========================================
echo    LuxTranslator - A iniciar...
echo  ========================================
echo.

cd /d "%~dp0"

echo  [1/3] A iniciar o servidor...
start "LuxTranslator Server" cmd /k "cd /d "%~dp0" && node server.js"
timeout /t 3 /nobreak > nul

echo  [2/3] A iniciar o ngrok...
start "LuxTranslator Ngrok" cmd /k "cd /d "%~dp0" && ngrok http 3000"
timeout /t 4 /nobreak > nul

echo  [3/3] A abrir o painel ngrok...
start chrome "http://127.0.0.1:4040"

echo.
echo  ========================================
echo    LuxTranslator ativo!
echo.
echo    1. Copia o link https://xxx.ngrok-free.app
echo       que aparece na janela do ngrok
echo    2. Abre esse link no teu telemovel
echo    3. Toca no microfone e diz "Teste"
echo  ========================================
echo.
pause
