@echo off
title LuxTranslator - A parar
color 0C
echo.
echo  A parar o LuxTranslator...
echo.
taskkill /f /im node.exe /t 2>nul
taskkill /f /im ngrok.exe /t 2>nul
npx kill-port 3000 2>nul
echo.
echo  LuxTranslator parado!
echo.
pause
